Sample app used in ZufarExplained's article on DevOps CI/CD pipeline in HackerNoon
* https://hackernoon.com/building-a-cicd-pipeline-with-aws-k8s-docker-ansible-git-github-apache-maven-and-jenkins
